import os
import re
import urllib.parse
import requests
import pandas as pd
from bs4 import BeautifulSoup
from google import genai
from combined_agent import MegaLongevityAgent
from html_formatter import generate_html_report

def download_direct_file(url, dest_dir="."):
    """Downloads a file directly from a URL."""
    response = requests.get(url, stream=True)
    response.raise_for_status()
    
    # Try to extract filename from headers
    cd = response.headers.get('content-disposition')
    filename = None
    if cd:
        fname_match = re.findall('filename="?([^"]+)"?', cd)
        if fname_match:
            filename = fname_match[0]
            
    if not filename:
        # Fallback to URL path extraction
        parsed_url = urllib.parse.urlparse(url)
        filename = os.path.basename(parsed_url.path)
        valid_exts = ['.csv', '.tsv', '.txt', '.xlsx', '.xls', '.json', '.parquet']
        if not filename or not any(filename.lower().endswith(ext) for ext in valid_exts):
            filename = "downloaded_dataset.csv" # Ultimate fallback
            
    filepath = os.path.join(dest_dir, filename)
    
    with open(filepath, 'wb') as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
            
    return filepath

def fetch_dataset_and_description(url, ai_client, model_name):
    """
    Analyzes a URL. If it's a webpage, uses AI to extract a description and finds the download link.
    If it's a direct file, downloads it immediately.
    """
    print(f"\n[*] Analyzing URL: {url}")
    
    try:
        # Use headers to mimic a browser to bypass basic anti-scraping
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.head(url, allow_redirects=True, headers=headers)
        content_type = response.headers.get('Content-Type', '').lower()
    except Exception as e:
        print(f"[!] Error connecting to URL: {e}")
        return None, None

    dataset_path = None
    dataset_description = "No specific web description available. Raw dataset was downloaded directly."

    # Scenario 1: It's a webpage (e.g., UCI, HuggingFace dataset page)
    if 'text/html' in content_type:
        print("[*] Webpage detected. Extracting metadata and searching for dataset links...")
        full_response = requests.get(url, headers=headers)
        soup = BeautifulSoup(full_response.text, 'html.parser')
        
        # Extract text to generate a description (limit to 15,000 chars to save context window)
        page_text = soup.get_text(separator=' ', strip=True)[:15000]
        
        try:
            prompt = f"You are a data science assistant. Analyze this dataset repository webpage text and extract a concise, 2-paragraph dataset description. Focus on what the data represents. Webpage Text:\n\n{page_text}"
            ai_response = ai_client.models.generate_content(model=model_name, contents=prompt)
            dataset_description = ai_response.text
            print("[*] Successfully generated dataset description from webpage.")
        except Exception as e:
            dataset_description = f"Failed to extract description via AI: {e}"
        
        # Attempt to find a direct download link on the page
        valid_exts = ['.csv', '.xlsx', '.xls', '.json', '.parquet', '.tsv']
        possible_links = [a['href'] for a in soup.find_all('a', href=True) if any(ext in a['href'].lower() for ext in valid_exts)]
        
        if possible_links:
            dl_url = urllib.parse.urljoin(url, possible_links[0])
            print(f"[*] Found dataset link: {dl_url}. Downloading...")
            dataset_path = download_direct_file(dl_url)
        else:
            print("[!] Could not automatically find a direct dataset download button/link on this page.")
            dataset_path = input("[?] Please paste the DIRECT download link for the dataset file: ").strip()
            dataset_path = download_direct_file(dataset_path)

    # Scenario 2: It's a direct file download (CSV, JSON, etc.)
    else:
        print("[*] Direct file URL detected. Downloading...")
        dataset_path = download_direct_file(url)
        
    print(f"[*] Dataset successfully saved to: {dataset_path}")
    return dataset_path, dataset_description

def get_universal_schema_summary(filepath):
    """Dynamically extracts headers and the first 2 rows of popular dataset formats."""
    if not os.path.exists(filepath):
        return "No dataset provided. Fallback Schema: PATIENT_ID, AGE, BIOMARKER_1, OUTCOME"
        
    ext = os.path.splitext(filepath)[1].lower()
    
    try:
        if ext == '.csv':
            df = pd.read_csv(filepath, nrows=2)
        elif ext in ['.tsv', '.txt']:
            df = pd.read_csv(filepath, sep='\t', nrows=2)
        elif ext in ['.xlsx', '.xls']:
            df = pd.read_excel(filepath, nrows=2)
        elif ext == '.json':
            df = pd.read_json(filepath)
            df = df.head(2)
        elif ext == '.parquet':
            df = pd.read_parquet(filepath)
            df = df.head(2)
        else:
            return f"Unsupported file format: {ext}. Please use CSV, TSV, TXT, Excel, JSON, or Parquet."
        
        headers = list(df.columns)
        rows = df.values.tolist()
        row1 = rows[0] if len(rows) > 0 else []
        row2 = rows[1] if len(rows) > 1 else []
        
        return f"Headers: {headers}\nSample Row 1: {row1}\nSample Row 2: {row2}"
        
    except Exception as e:
        return f"Error reading dataset {filepath}: {str(e)}"

def run_pipeline():
    print("=================================================================")
    print("Initializing Universal Data Longevity Pipeline (Free Tier)...")
    print("=================================================================\n")
    
    gemini_api_key = os.getenv("GEMINI_API_KEY")
    ncbi_api_key = os.getenv("NCBI_API_KEY", "")
    
    if not gemini_api_key:
        print("ERROR: GEMINI_API_KEY environment variable is missing.")
        return

    # Initialize Modern Google GenAI Client
    ai_client = genai.Client()
    model_name = "gemini-2.5-flash"

    # 1. Load the Context Abstract
    abstract_path = "./abstract.txt"
    if not os.path.exists(abstract_path):
        print(f"ERROR: Missing {abstract_path}. Please create it and paste your study context.")
        return
    with open(abstract_path, "r", encoding="utf-8") as f:
        abstract_info = f.read()

    # 2. Fetch Dataset via URL Input
    dataset_url = input("[?] Enter a dataset URL to download (or press Enter to use local './dataset.xlsx'): ").strip()
    
    if dataset_url:
        dataset_path, dataset_description = fetch_dataset_and_description(dataset_url, ai_client, model_name)
        if not dataset_path:
            print("ERROR: Failed to acquire dataset.")
            return
            
        # Store the dataset description for future pre-programmed steps
        desc_path = "./dataset_metadata.txt"
        with open(desc_path, "w", encoding="utf-8") as f:
            f.write(dataset_description)
        print(f"[*] Dataset description saved to {desc_path}")
        
    else:
        dataset_path = "./dataset.xlsx"
        print(f"[*] No URL provided. Defaulting to local file: {dataset_path}")

    # 3. Load the Dataset Schema
    dataset_schema = get_universal_schema_summary(dataset_path)
    print(f"[Master] Loaded Abstract and Schema from {dataset_path}. Initiating processing...")

    # 4. Run the single Mega-Agent
    agent = MegaLongevityAgent(ai_client=ai_client, model_name=model_name, ncbi_api_key=ncbi_api_key)
    agent.run(abstract_info, dataset_schema)

    generate_html_report()

    print("\n=================================================================")
    print("Pipeline Execution Completed Successfully.")
    print("Check your directory for the generated output files.")
    print("=================================================================")

if __name__ == "__main__":
    run_pipeline()