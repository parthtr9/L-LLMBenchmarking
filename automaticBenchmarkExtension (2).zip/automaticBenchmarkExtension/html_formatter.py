import os
import re
import markdown

def generate_html_report(output_filename="final_benchmark_report.html"):
    print("\n--- Generating HTML Benchmark Report ---")
    
    templates_path = "prompt_templates_output.txt"
    
    def read_file(filepath):
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read()
        return f"> **Warning:** File `{filepath}` not found."

    templates_md = read_file(templates_path)
    
    # --- PRE-PROCESSING: Separation & Flexible Table Formatting ---
    
    # Req 4: Clear Separation. Inject a distinct HTML divider before the Prompt Templates start.
    # Looks for headings that contain "Prompt" or "Template".
    templates_md = re.sub(
        r'(#+\s*.*?(?:Prompt|Template).*?)', 
        r'\n\n<hr class="section-divider">\n\n\1', 
        templates_md, 
        flags=re.IGNORECASE
    )

    lines = templates_md.split('\n')
    new_lines = []
    in_table = False
    
    for line in lines:
        stripped = line.strip()
        
        # Req 1: Remove empty rows. If we are in the table and hit an empty line, close the table.
        if not stripped:
            if in_table:
                in_table = False
            new_lines.append("")
            continue

        # Match bullet points with colons (e.g., "- Target (Y): Description")
        match = re.match(r'^[\*\-]\s*\*{0,2}([^:]+)\*{0,2}:\s*(.+)$', stripped)
        
        # Req 6: Flexible format. Only convert to table if it explicitly looks like a variable list.
        # This prevents standard prompt instruction lists from being forced into a table.
        is_variable = match and bool(re.search(r'\b(target|feature|variable|x|y)\b', match.group(1), re.IGNORECASE))
        
        if is_variable:
            if not in_table:
                new_lines.append("\n| Variable / Feature | Description |")
                new_lines.append("|---|---|")
                in_table = True
            
            var_name = match.group(1).strip()
            desc = match.group(2).strip()
            
            # Req 3: Remove example data values for categorical variables.
            # Strips out anything in parentheses/brackets containing "e.g.", "i.e.", or "example".
            desc = re.sub(r'[\(\[].*?(?:e\.g\.|i\.e\.|example).*?[\)\]]', '', desc, flags=re.IGNORECASE).strip()

            new_lines.append(f"| **{var_name}** | {desc} |")
        else:
            if in_table:
                in_table = False
            new_lines.append(line)
            
    templates_md = '\n'.join(new_lines)
    
    # Initialize Markdown parser
    md_parser = markdown.Markdown(extensions=['tables', 'fenced_code', 'sane_lists'])
    templates_html = md_parser.convert(templates_md)
    
    # HTML and CSS Template
    html_template = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Longevity AI Benchmark Report</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <style>
        /* Req 2: Ensure EVERYTHING uses the exact same font. */
        * {{
            font-family: 'Inter', sans-serif !important;
        }}
        
        :root {{
            --bg-color: #f4f7f9;
            --text-color: #2c3e50;
            --card-bg: #ffffff;
            --accent-color: #1a5f7a;
            --border-color: #e1e8ed;
        }}
        body {{
            background-color: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
            margin: 0;
            padding: 40px 20px;
        }}
        .container {{
            max-width: 1000px;
            margin: 0 auto;
        }}
        header {{
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 3px solid var(--accent-color);
        }}
        h1, h2, h3 {{
            color: var(--accent-color);
            font-weight: 700;
        }}
        
        .section-card {{
            background-color: var(--card-bg);
            border-radius: 12px;
            padding: 35px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.04);
            border: 1px solid var(--border-color);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}
        .section-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 12px 20px rgba(0,0,0,0.08);
        }}
        
        .templates-card {{
            border-top: 6px solid #3498db;
        }}

        /* Req 4: Clear Separation styling */
        hr.section-divider {{
            border: 0;
            height: 5px;
            background: linear-gradient(to right, #3498db, #1a5f7a);
            margin: 45px 0;
            border-radius: 3px;
        }}

        /* Table Styling for Target Variables */
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.95em;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0,0,0,0.03);
        }}
        th, td {{
            padding: 15px 20px;
            border-bottom: 1px solid var(--border-color);
            text-align: left;
        }}
        th {{
            background-color: var(--accent-color);
            color: white;
            font-weight: 600;
        }}
        tr:nth-child(even) {{
            background-color: #fcfcfc;
        }}
        tr:hover {{
            background-color: #f1f5f9;
        }}

        /* Req 5: Explicit Box Styling & Text Wrapping for Prompt Templates */
        pre {{
            background-color: #1e293b;
            color: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            font-size: 0.95em;
            border: 1px solid #0f172a;
            
            /* Forces text to wrap inside the box to prevent bleeding */
            white-space: pre-wrap;       
            white-space: -moz-pre-wrap;  
            white-space: -pre-wrap;      
            white-space: -o-pre-wrap;    
            word-wrap: break-word;       
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Longevity AI Benchmarking</h1>
            <p>Target Variables & Frontier Prompt Templates</p>
        </header>

        <div class="section-card templates-card">
            {templates_html}
        </div>
    </div>
</body>
</html>
"""

    with open(output_filename, "w", encoding="utf-8") as f:
        f.write(html_template)
        
    print(f"[HTML Formatter] Success! Created focused report at '{output_filename}'")

if __name__ == "__main__":
    generate_html_report()