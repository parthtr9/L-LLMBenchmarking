import os
import requests
import xml.etree.ElementTree as ET

class MegaLongevityAgent:
    def __init__(self, ai_client, model_name, ncbi_api_key="AIzaSyCBSAT9bGfzj7A7U9iswNE1BEP1gdRXIhc"):
        self.client = ai_client
        self.model_name = model_name
        self.ncbi_api_key = ncbi_api_key

    def _query_ncbi_pubmed(self, keyword):
        output_dir = "./research_papers"
        os.makedirs(output_dir, exist_ok=True)
        
        # --- CACHING CHECK ---
        existing_files = [f for f in os.listdir(output_dir) if f.startswith("PMID_") and f.endswith(".txt")]
        if len(existing_files) >= 3:
            print(f"[PubMed] Found {len(existing_files)} locally cached papers in '{output_dir}/'. Skipping download to save quota...")
            accumulated_text = ""
            for filename in existing_files:
                with open(os.path.join(output_dir, filename), "r", encoding="utf-8") as f:
                    accumulated_text += f.read() + "\n"
            return accumulated_text

        clean_keyword = keyword.split(',')[0].strip().replace('"', '')
        print(f"[PubMed] Querying NCBI for single term: '{clean_keyword}'...")
        
        search_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
        search_params = {"db": "pubmed", "term": f"{clean_keyword} AND review[Filter]", "retmax": 5, "retmode": "json"}
        if self.ncbi_api_key: search_params["api_key"] = self.ncbi_api_key

        try:
            search_response = requests.get(search_url, params=search_params, timeout=15)
            search_response.raise_for_status()
            id_list = search_response.json().get("esearchresult", {}).get("idlist", [])
            
            if not id_list:
                print("[PubMed] No matches. Re-trying with 'Geroscience'...")
                search_params["term"] = "Geroscience AND review[Filter]"
                search_response = requests.get(search_url, params=search_params, timeout=15)
                id_list = search_response.json().get("esearchresult", {}).get("idlist", [])

            if not id_list:
                return "Alternative base: DNA methylation acceleration models and transcriptomic drift indicators."

            fetch_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
            fetch_params = {"db": "pubmed", "id": ",".join(id_list), "retmode": "xml"}
            if self.ncbi_api_key: fetch_params["api_key"] = self.ncbi_api_key

            fetch_response = requests.get(fetch_url, params=fetch_params, timeout=20)
            fetch_response.raise_for_status()
            
            root = ET.fromstring(fetch_response.content)
            accumulated_text = ""
            
            for index, article in enumerate(root.findall('.//PubmedArticle')):
                pmid = article.find('.//PMID').text if article.find('.//PMID') is not None else f"unknown_{index}"
                title = article.find('.//ArticleTitle').text if article.find('.//ArticleTitle') is not None else "No Title"
                abstract = " ".join([e.text for e in article.findall('.//AbstractText') if e.text]) or "Abstract empty."

                file_content = f"PMID: {pmid}\nTitle: {title}\nAbstract: {abstract}\n\n"
                accumulated_text += file_content
                
                # OUTPUT A: Downloaded research papers permanently saved
                with open(f"{output_dir}/PMID_{pmid}.txt", "w", encoding="utf-8") as f:
                    f.write(file_content)

            print(f"[PubMed] Successfully downloaded {len(id_list)} papers to '{output_dir}/'")
            return accumulated_text

        except Exception as e:
            print(f"[PubMed] API Error: {e}. Utilizing fallback context.")
            return "Fallback abstract data context regarding transcriptomic velocity drift."

    def run(self, abstract_info, dataset_schema):
        print("\n--- Running Mega-Agent: Combined Extraction & Generation ---")
        
        # API CALL 1: Keyword Extraction (Skipped if cache exists)
        if os.path.exists("./research_papers") and len(os.listdir("./research_papers")) >= 3:
            keyword = "CACHED"
        else:
            keyword_prompt = f"Extract the single most important broad biological keyword from this abstract: {abstract_info}. Return ONLY the word."
            keyword = self.client.models.generate_content(model=self.model_name, contents=keyword_prompt).text.strip()
        
        # Download or load papers (OUTPUT A)
        downloaded_papers = self._query_ncbi_pubmed(keyword)
        
        # API CALL 2: The Mega-Prompt Synthesis
        mega_prompt = f"""
You are an advanced longevity biology benchmarking AI. I am providing you with a study abstract, downloaded scientific papers, and a raw dataset CSV schema. 
You must analyze all of this together and output three distinct artifacts. 

You MUST wrap each artifact in the specific XML tags provided below so I can parse your response.

<RESEARCH_REPORT>
Synthesize findings from the DOWNLOADED PAPERS and ABSTRACT into a comprehensive research report detailing biological significance, biomarkers, and experimental frameworks.
</RESEARCH_REPORT>

<LABELED_METADATA>
Map the ambiguous dataset columns (from the DATASET SCHEMA) to explicit definitions based on the research report. Filter out unused columns. Output as a Markdown table.
</LABELED_METADATA>

<PROMPT_TEMPLATES>
Define target variables (Y) and predictive features (X). Generate highly rigorous LLM prompt templates designed to test a frontier AI based on this data. Include a dual-layer validation profile (Semantic consistency and biological tolerance limits).
</PROMPT_TEMPLATES>

--- INPUTS ---
ABSTRACT/CONTEXT:
{abstract_info}

DATASET SCHEMA (Headers & Sample Rows):
{dataset_schema}

DOWNLOADED PAPERS:
{downloaded_papers}
"""
        print("[Mega-Agent] Sending unified synthesis prompt to Gemini (This saves API quota)...")
        response = self.client.models.generate_content(
            model=self.model_name,
            contents=mega_prompt
        )
        
        full_text = response.text
        
        # Parse and save outputs
        import re
        
        report_match = re.search(r"<RESEARCH_REPORT>(.*?)</RESEARCH_REPORT>", full_text, re.DOTALL)
        metadata_match = re.search(r"<LABELED_METADATA>(.*?)</LABELED_METADATA>", full_text, re.DOTALL)
        templates_match = re.search(r"<PROMPT_TEMPLATES>(.*?)</PROMPT_TEMPLATES>", full_text, re.DOTALL)

        # OUTPUT B: Research Report
        with open("research_report_output.md", "w", encoding="utf-8") as f:
            f.write(report_match.group(1).strip() if report_match else "Report parsing failed. Check raw output.")
            
        # OUTPUT C: Labeled Metadata
        with open("labeled_metadata_output.md", "w", encoding="utf-8") as f:
            f.write(metadata_match.group(1).strip() if metadata_match else "Metadata parsing failed.")
            
        # OUTPUT D: Final Prompt Templates
        with open("prompt_templates_output.txt", "w", encoding="utf-8") as f:
            f.write(templates_match.group(1).strip() if templates_match else "Template parsing failed.")

        print("[Mega-Agent] Complete! All artifacts successfully parsed and written to disk.")